<?php

// Porto Preview Image
add_shortcode('porto_preview_image', 'porto_shortcode_preview_image');
add_action('vc_after_init', 'porto_load_preview_image_shortcode');

function porto_shortcode_preview_image($atts, $content = null) {
    ob_start();
    if ($template = porto_shortcode_template('porto_preview_image'))
        include $template;
    return ob_get_clean();
}

function porto_load_preview_image_shortcode() {
    $custom_class = porto_vc_custom_class();

    vc_map( array(
        "name" => "Porto " . __("Preview Image", 'porto-shortcodes'),
        "base" => "porto_preview_image",
        "category" => __("Porto", 'porto-shortcodes'),
        "icon" => "porto_vc_preview_image",
        "params" => array(
            array(
                'type' => 'vc_link',
                'heading' => __( 'URL (Link)', 'porto-shortcodes' ),
                'param_name' => 'link',
                'description' => __( 'Add link to image.', 'porto-shortcodes' )
            ),
            array(
                'type' => 'label',
                'heading' => __('Input Image URL or Select Image.', 'porto-shortcodes'),
                'param_name' => 'label'
            ),
            array(
                'type' => 'textfield',
                'heading' => __('Image URL', 'porto-shortcodes'),
                'param_name' => 'image_url'
            ),
            array(
                'type' => 'attach_image',
                'heading' => __('Image', 'porto-shortcodes'),
                'param_name' => 'image_id'
            ),
            array(
                'type' => 'checkbox',
                'heading' => __('Fixed Image', 'porto-shortcodes'),
                'param_name' => 'fixed',
                'value' => array(__('Yes, please', 'js_composer') => 'yes'),
                'admin_label' => true
            ),
            array(
                'type' => 'dropdown',
                'heading' => __('Fixed Position', 'porto-shortcodes'),
                'param_name' => 'fixed_pos',
                'value' => porto_sh_commons('preview_position'),
                'dependency' => array('element' => 'fixed', 'not_empty' => true)
            ),
            array(
                'type' => 'dropdown',
                'heading' => __('Preview Time', 'porto-shortcodes'),
                'param_name' => 'time',
                'value' => porto_sh_commons('preview_time'),
                'admin_label' => true
            ),
            array(
                'type' => 'checkbox',
                'heading' => __('Disable Border', 'porto-shortcodes'),
                'param_name' => 'noborders',
                'value' => array(__('Yes, please', 'js_composer') => 'yes'),
                'admin_label' => true
            ),
            array(
                'type' => 'checkbox',
                'heading' => __('Enable Box Shadow', 'porto-shortcodes'),
                'param_name' => 'boxshadow',
                'value' => array(__('Yes, please', 'js_composer') => 'yes'),
                'admin_label' => true
            ),
            array(
                'type' => 'textfield',
                'heading' => __('Preview Height', 'porto-shortcodes'),
                'param_name' => 'height',
                'value' => '232px'
            ),
            array(
                'type' => 'textfield',
                'heading' => __('Tip Label', 'porto-shortcodes'),
                'param_name' => 'tip_label'
            ),
            array(
                'type' => 'dropdown',
                'heading' => __('Tip Skin Color', 'porto-shortcodes'),
                'param_name' => 'tip_skin',
                'std' => 'custom',
                'value' => porto_sh_commons('colors')
            ),
            $custom_class
        )
    ) );

    if (!class_exists('WPBakeryShortCode_Porto_Preview_Image')) {
        class WPBakeryShortCode_Porto_Preview_Image extends WPBakeryShortCode {
        }
    }
}